package com.example.demo.core;

import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.StudentNotFoundException;
import com.example.demo.model.Gender;
import com.example.demo.model.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    private StudentService sut;
    @Mock
    private StudentRepository studentRepository;

    @BeforeEach
    void setUp(){
        sut = new StudentService(studentRepository);
    }

    @Test
    void getAllStudents() {
        //arrange

        //act
        sut.getAllStudents();
        //assert
        verify(studentRepository).findAll();
    }

    @Test
    void studentServiceSavesStudentIfNotExistInDatabase() {
        //arrange
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        ArgumentCaptor<Student> captor = ArgumentCaptor.forClass(Student.class);
        //act
        sut.addStudent(student);
        //assert
        verify(studentRepository).save(captor.capture());
        assertThat(captor.getValue()).isEqualTo(student);
    }
    @Test
    void StudentServiceThrowsExWhenStudentExistInDatabase(){
        //arrande
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        when(studentRepository.selectExistsEmail(any())).thenReturn(true);
        //act
        //assert
        assertThatThrownBy(() -> sut.addStudent((student))).isInstanceOf(
                BadRequestException.class
        ).hasMessage("Email " + student.getEmail() + " taken");
    }

    @Test
    void StudentServiceDeliteIfExist() {
        //arrange
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        Long id = student.getId();
        when(studentRepository.existsById(any())).thenReturn(true);
        //act
        sut.deleteStudent(id);
        //assert
        verify(studentRepository).deleteById(id);

    }

    @Test
    void StudentServiceNotDeleteThrowsExIfNotExist() {
        //arrange
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        Long id = student.getId();
        when(studentRepository.existsById(any())).thenReturn(false);
        //act
        //assert
        assertThatThrownBy(() -> sut.deleteStudent(id)).isInstanceOf(
                StudentNotFoundException.class
        ).hasMessage("Student with id " + student.getId() + " does not exists");
    }
    @Test
    void studentServiceGetStudentIfExistsInDatabase() {
        // Arrange
        Long id = 1L;
        when(studentRepository.existsById(id)).thenReturn(true);
        // Act
        sut.getStudent(id);
        // Assert
        verify(studentRepository).findById(id);
    }

    @Test
    void studentServiceThrowExceptionWhenGetStudentIfDoesNotExistsInDatabase() {
        // Arrange
        Long id = 1L;
        when(studentRepository.existsById(id)).thenReturn(false);
        // Act
        // Assert
        assertThatThrownBy(() -> sut.getStudent(id))
                .isInstanceOf(StudentNotFoundException.class)
                .hasMessage("Student with id " + id + " does not exists");
    }

}