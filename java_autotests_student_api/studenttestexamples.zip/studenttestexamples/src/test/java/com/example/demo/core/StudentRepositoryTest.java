package com.example.demo.core;

import com.example.demo.model.Gender;
import com.example.demo.model.Student;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class StudentRepositoryTest {
    @Autowired
    private StudentRepository studentRepository;
    @Test
    void selectExistsEmailRetutnsTrue() {
        //arrange
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        studentRepository.save(student);
        // act
        boolean result = studentRepository.selectExistsEmail(student.getEmail());
        //assert
        assertThat(result).isTrue();
    }
    @Test
    void selectExistsEmailRetutnsFalse() {
        //arrange
        Student student = new Student("John", "John@test.ru", Gender.MALE);
        // act
        boolean result = studentRepository.selectExistsEmail(student.getEmail());
        //assert
        assertThat(result).isFalse();
    }

    @AfterEach
    void tearDown() {
        studentRepository.deleteAll();
    }
}